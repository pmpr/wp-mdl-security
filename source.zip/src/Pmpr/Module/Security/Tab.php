<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069a12c76e9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security; class Tab extends Container { public function kgquecmsgcouyaya() { $uusmaiomayssaecw = Setting::symcgieuakksimmu()->cisyiemkeykgkomc(); $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$uusmaiomayssaecw}\137\x74\x61\142\x73"), [$this, "\x61\x75\x63\151\x6d\x67\167\x73\x77\155\x67\x61\157\x63\x61\x65"])->cecaguuoecmccuse("\142\145\146\157\x72\x65\137\163\x61\x76\x65\137{$uusmaiomayssaecw}\x5f\157\x70\x74\151\157\x6e\163", [$this, "\x71\x6d\x71\x6f\x67\x75\163\x6f\x61\161\x65\x79\x67\x65\167\155"], 10, 2); } public function aucimgwswmgaocae($ywoucyskcquysiwc) { return $ywoucyskcquysiwc; } public function qmqogusoaqeygewm($qiouiwasaauyaaue, $scegeeyqweaksmki) { return $qiouiwasaauyaaue; } }
