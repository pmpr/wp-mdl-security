<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668401096bc30             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security; class Tab extends Container { public function kgquecmsgcouyaya() { $uusmaiomayssaecw = Setting::symcgieuakksimmu()->cisyiemkeykgkomc(); $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$uusmaiomayssaecw}\x5f\x74\141\142\x73"), [$this, "\x61\x75\143\x69\155\147\167\x73\x77\155\x67\141\157\x63\x61\x65"])->cecaguuoecmccuse("\142\x65\146\157\x72\x65\x5f\163\141\166\x65\137{$uusmaiomayssaecw}\137\x6f\160\x74\x69\157\x6e\x73", [$this, "\161\x6d\x71\157\x67\165\163\157\141\x71\x65\x79\x67\x65\167\155"], 10, 2); } public function aucimgwswmgaocae($ywoucyskcquysiwc) { return $ywoucyskcquysiwc; } public function qmqogusoaqeygewm($qiouiwasaauyaaue, $scegeeyqweaksmki) { return $qiouiwasaauyaaue; } }
