<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870846882a3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security; class Tab extends Container { public function kgquecmsgcouyaya() { $uusmaiomayssaecw = Setting::symcgieuakksimmu()->cisyiemkeykgkomc(); $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$uusmaiomayssaecw}\x5f\x74\141\142\163"), [$this, "\141\x75\x63\151\x6d\147\167\x73\x77\155\x67\141\x6f\x63\x61\145"])->cecaguuoecmccuse("\x62\145\x66\x6f\162\x65\x5f\163\x61\166\x65\137{$uusmaiomayssaecw}\x5f\x6f\160\x74\151\x6f\156\163", [$this, "\161\x6d\161\x6f\x67\165\163\157\141\161\145\x79\x67\145\x77\x6d"], 10, 2); } public function aucimgwswmgaocae($ywoucyskcquysiwc) { return $ywoucyskcquysiwc; } public function qmqogusoaqeygewm($qiouiwasaauyaaue, $scegeeyqweaksmki) { return $qiouiwasaauyaaue; } }
