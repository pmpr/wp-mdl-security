<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e424209868             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security; class Tab extends Container { public function kgquecmsgcouyaya() { $uusmaiomayssaecw = Setting::symcgieuakksimmu()->cisyiemkeykgkomc(); $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$uusmaiomayssaecw}\x5f\x74\141\142\163"), [$this, "\141\x75\143\x69\155\147\x77\x73\x77\155\x67\141\157\x63\x61\145"])->cecaguuoecmccuse("\142\x65\x66\157\162\x65\x5f\x73\x61\x76\x65\x5f{$uusmaiomayssaecw}\x5f\157\160\x74\151\157\x6e\x73", [$this, "\161\155\x71\x6f\x67\x75\x73\157\141\161\145\171\147\145\167\x6d"], 10, 2); } public function aucimgwswmgaocae($ywoucyskcquysiwc) { return $ywoucyskcquysiwc; } public function qmqogusoaqeygewm($qiouiwasaauyaaue, $scegeeyqweaksmki) { return $qiouiwasaauyaaue; } }
