<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a661c737a19             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Defender\Config; use Pmpr\Module\Security\Container; class Config extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('the_generator', [$this, 'egoywceauwkgyuyo'])->cecaguuoecmccuse('get_the_generator_rdf', [$this, 'egoywceauwkgyuyo'])->cecaguuoecmccuse('get_the_generator_html', [$this, 'egoywceauwkgyuyo'])->cecaguuoecmccuse('get_the_generator_atom', [$this, 'egoywceauwkgyuyo'])->cecaguuoecmccuse('get_the_generator_rss2', [$this, 'egoywceauwkgyuyo'])->cecaguuoecmccuse('get_the_generator_xhtml', [$this, 'egoywceauwkgyuyo'])->cecaguuoecmccuse('get_the_generator_export', [$this, 'egoywceauwkgyuyo'])->cecaguuoecmccuse('get_the_generator_comment', [$this, 'egoywceauwkgyuyo']); } public function egoywceauwkgyuyo($kqagasmwymmuiksq) { if ($this->weysguygiseoukqw(Setting::sywykwyaqameeyse)) { $kqagasmwymmuiksq = ''; } return $kqagasmwymmuiksq; } }
