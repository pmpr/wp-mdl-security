<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fc6daa0050             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Defender; use Pmpr\Module\Security\Container; use Pmpr\Module\Security\Defender\Auth\Auth; use Pmpr\Module\Security\Defender\Config\Config; class Defender extends Container { public function mameiwsayuyquoeq() { Auth::symcgieuakksimmu(); Config::symcgieuakksimmu(); } }
