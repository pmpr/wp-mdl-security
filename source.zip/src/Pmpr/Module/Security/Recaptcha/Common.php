<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56f66a8c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Recaptcha; use Pmpr\Module\Security\Container; class Common extends Container { }
