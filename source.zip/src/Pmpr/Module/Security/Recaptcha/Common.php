<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eebc2125a6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Recaptcha; use Pmpr\Module\Security\Container; class Common extends Container { }
