<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada874e2a0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Recaptcha; use Pmpr\Module\Security\Container; class Common extends Container { }
