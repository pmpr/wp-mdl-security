<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce66e18040c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); $this->igiywquyccyiaucw(Constants::kekcgssiyagioocg, 50); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x53\x65\x63\x75\x72\151\164\x79\40\x53\x65\164\164\x69\156\147", PR__MDL__SECURITY); $this->igiywquyccyiaucw(Constants::qsegwakiwaiyimyy, __("\123\145\x63\x75\x72\x69\164\171", PR__MDL__SECURITY)); } }
