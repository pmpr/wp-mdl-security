<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd2157ec168             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); $this->igiywquyccyiaucw(self::kekcgssiyagioocg, 50); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x53\145\143\x75\162\151\x74\x79\40\x53\145\164\164\151\x6e\x67", PR__MDL__SECURITY); $this->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\x53\x65\x63\x75\162\151\x74\x79", PR__MDL__SECURITY)); } }
