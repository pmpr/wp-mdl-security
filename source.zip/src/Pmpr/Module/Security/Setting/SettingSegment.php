<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd2157ec168             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; use Pmpr\Module\Security\Interfaces\CommonInterface; abstract class SettingSegment extends Segment implements CommonInterface { public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
