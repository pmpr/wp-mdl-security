<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6801065d8efaf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Section; class SettingSection extends Section { public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
